import os
import time
import argparse
import logging
from dotenv import load_dotenv

from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt, Prompt

load_dotenv()

from storage.db import db
from sources.instagram import InstagramSource
from sources.tiktok import TikTokSource
from transcription.local_transcriber import client as ig_client
from summarizer.groq_extractor import extractor as groq_client

from transcription.caption_aware_transcriber import client as tiktok_client

console = Console()

os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    filename='logs/pipeline_errors.log',
    level=logging.ERROR,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def detect_platform(url: str) -> str:
    if "instagram.com" in url:
        return "instagram"
    elif "tiktok.com" in url:
        return "tiktok"
    else:
        raise ValueError(f"Unrecognized platform URL: {url}")

def process_video(video_meta, target_lang: str, domain: str):
    try:
        if db.is_processed(video_meta.platform_id):
            console.print(f"[dim][-] Skipping {video_meta.platform_id}: Already in database.[/dim]")
            return

        # 1. Transcribe (Smart Routing)
        with console.status(f"[cyan][*][/cyan] Processing [bold]{video_meta.platform_id}[/bold]..."):
            
            if video_meta.platform == "tiktok":
                transcript = tiktok_client.get_transcript(video_meta, target_lang, domain)
            else:
                transcript = ig_client.get_transcript(video_meta, target_lang, domain)
        
        if not transcript or not transcript.text:
            console.print(f"[yellow][!][/yellow] No usable transcript for {video_meta.platform_id}.")
            return

        # 2. Save Raw File
        date_str = video_meta.posted_at.strftime('%Y-%m-%d')
        transcript_dir = f"output/@{video_meta.creator_username}/transcripts"
        os.makedirs(transcript_dir, exist_ok=True)
        
        raw_path = os.path.join(transcript_dir, f"{date_str}_{video_meta.platform_id}_raw.txt")
        with open(raw_path, "w", encoding="utf-8") as f:
            f.write(transcript.text)

        # 3. Clean Transcript (Groq Editor)
        console.print(f"    [dim]-> AI Cleaning & Code-Switching Fix...[/dim]")
        cleaned_text = groq_client.clean_transcript(transcript.text, target_lang)

        # 4. Save Cleaned File (So you can compare the magic!)
        clean_path = os.path.join(transcript_dir, f"{date_str}_{video_meta.platform_id}_clean.txt")
        with open(clean_path, "w", encoding="utf-8") as f:
            f.write(cleaned_text)

        # 5. Summarize
        console.print(f"[cyan][*][/cyan] Extracting hard data via Groq...")
        summary = groq_client.summarize(transcript, cleaned_text)

        # 6. Save & Commit
        os.makedirs(os.path.dirname(summary.file_path), exist_ok=True)
        with open(summary.file_path, "w", encoding="utf-8") as f:
            f.write(summary.markdown)

        db.mark_processed(video_meta, summary.file_path, transcript.source)
        console.print(f"[bold green][✓] Success:[/bold green] {summary.file_path}")

    except Exception as e:
        console.print(f"[bold red][X] Error processing {video_meta.platform_id}:[/bold red] {e}")
        logging.exception(f"Failed to process {video_meta.platform_id}")

def add_creator_flow(username: str, platform: str):
    source = InstagramSource() if platform == "instagram" else TikTokSource()
    username_clean = username.replace("@", "")
    
    console.print(f"\n[cyan][*][/cyan] Scanning [bold]@{username_clean}[/bold] on {platform}...")
    profile_info = source.get_profile_stats(username_clean) 
    
    panel_text = (
        f"[bold blue]@{profile_info.username}[/bold blue]\n"
        f"[yellow]{profile_info.total_posts}[/yellow] posts total\n\n"
        f"Scanned: [dim]{profile_info.scanned_at.strftime('%b %d, %Y %I:%M%p')}[/dim]"
    )
    console.print(Panel(panel_text, title="[bold cyan]Creator Registry[/bold cyan]", border_style="cyan", expand=False))

    db.add_profile(profile_info.username, platform)
    
    # --- MENUS ---
    console.print("\n[bold]Select Primary Language:[/bold]")
    target_lang = Prompt.ask("Language", choices=["ar", "en", "de", "auto"], default="ar")

    console.print("\n[bold]Select Content Domain (for AI vocabulary hint):[/bold]")
    domain = Prompt.ask("Domain", choices=["tech", "medical", "political", "general"], default="tech")
    
    console.print("\n[bold]What would you like to process?[/bold]")
    console.print("[cyan]1.[/cyan] Latest 5 posts")
    console.print("[cyan]2.[/cyan] Latest 20 posts")
    
    choice = IntPrompt.ask("\nSelect an option", choices=["1", "2"])
    
    limit = 5 if choice == 1 else 20
    console.print(f"[cyan][*][/cyan] Fetching latest [yellow]{limit}[/yellow] posts...")
    posts = source.get_recent_posts(profile_info.username, limit)
    
    # --- TIME TRACKING ---
    start_time = time.time()
    
    for p in posts:
        process_video(p, target_lang, domain) 
        
    total_time = time.time() - start_time
    console.print(f"\n[bold magenta]🏁 Run Complete[/bold magenta]")
    console.print(f"Total time: [yellow]{total_time:.1f} seconds[/yellow] for {len(posts)} videos.")

def main():
    parser = argparse.ArgumentParser(description="Digestr Pipeline")
    parser.add_argument("target", nargs="?", help="URL or username")
    parser.add_argument("--add", action="store_true", help="Add new creator")
    parser.add_argument("--platform", choices=["instagram", "tiktok"], default="instagram")

    args = parser.parse_args()

    if args.add and args.target:
        add_creator_flow(args.target, args.platform)
    elif args.target:
        # Single video flow fallback (defaults to auto/general)
        platform = detect_platform(args.target)
        source = InstagramSource() if platform == "instagram" else TikTokSource()
        video_meta = source.get_single_post(args.target)
        db.add_profile(video_meta.creator_username, platform)
        process_video(video_meta, "auto", "general")
    else:
        parser.print_help()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n[yellow][!] Stopped by user.[/yellow]")
    except Exception as e:
        console.print(f"\n[bold red][FATAL][/bold red] {e}")
        logging.exception("Fatal crash")